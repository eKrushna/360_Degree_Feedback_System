# Student_Feedback_System
Feedback system for students to rate the real time performance of faculty and about institution. • Designed a software using Java as front-end and MySQL as back-end in which students can give their feedback on the basis of different parameters.
# OVERVIEW OF PROJECT : Student Feedback System

This project is a JAVA based GUI application with back end controlled by JDBC
Database used MySQL
The project Student Feedback System consist of JFrame windows having student feedback form
regarding the Institution and regarding the faculty So, the students can give their feedback easily
by selecting the appropriate grade
This project is made to replace the currently ongoing traditional paper method of feedback

# WORKING OF PROJECT :
(Student’s Information Window)
At first Welcome window appears
After clicking Continue button,
Student’s Information window appears
Already registered students click on login
New students click on Signup for registration

SIGNUP WINDOW :
In Signup window Students can fill all the required information.
After filling of information click on Signup button to complete registration.
There is also some constraints that if a student keepany information empty or fills in incorrect format the
it shows error message.

LOGIN WINDOW :
In Login window Students can fill all the required information.
After filling of information click on Login button to complete Login process to submit the feedback.
There is also some constraints that if a student keep any information empty or fills in incorrect format the
it shows error message.
The error message shown is “Empty field” or
“Username and password not matched"

Institute Evaluation Window :
This is Institute Evaluation window of the project Student
Feedback System in which student can give their
feedback about the Institute in which they are studying.
Students can easily evaluate the institute by entering
their Course Name & Session.
Students can select the appropriate grade on the basis
of factors given.
When Submit button is clicked then the feedback is
saved to the database.
When Next button is clicked then we go to the faculty
evaluation window.
Close button is clicked for closing the window.

Faculty Evaluation Window :
This is the next window of the project Student
Feedback System in which student can give their
feedback about the faculty who is teaching them
•
Students can easily evaluate the faculty by
entering their Faculty Name, Subject taught,
Course Name Session
•
Students can select the appropriate grade on the
basis of factors given
•
When Submit button is clicked then the feedback
is saved to the database
•
When Previous button is clicked then we go to the
Institute evaluation window
•
Close button is clicked for closing the window
